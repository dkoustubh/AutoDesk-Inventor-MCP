# ATS Autodesk Multi-Shape Native Agent (AutoCAD & Inventor)
param(
    [string]$ServerUrl = "ws://192.168.11.94:8005",
    [string]$WorkstationIp = "192.168.11.150"
)

$host.UI.RawUI.WindowTitle = "ATS Multi-Shape CAD Agent — $WorkstationIp"
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host " ATS Multi-Shape Autodesk Native Agent" -ForegroundColor Cyan
Write-Host " Supports: Cubes, Boxes, Cylinders, Spheres, Cones, Toruses, Plates" -ForegroundColor White
Write-Host " Connecting to: $ServerUrl" -ForegroundColor White
Write-Host " Workstation:   $WorkstationIp" -ForegroundColor White
Write-Host "===================================================" -ForegroundColor Cyan

function Execute-CADCommand($action, $params) {
    Write-Host "[CAD] Executing $action with params: $($params | ConvertTo-Json -Compress)..." -ForegroundColor Yellow

    # Extract dimensions
    $l = if ($params.length_mm) { [double]$params.length_mm } else { 30.0 }
    $w = if ($params.width_mm) { [double]$params.width_mm } else { 30.0 }
    $h = if ($params.height_mm) { [double]$params.height_mm } else { 30.0 }
    $rad = if ($params.radius_mm) { [double]$params.radius_mm } elseif ($params.diameter_mm) { [double]$params.diameter_mm / 2.0 } else { 15.0 }
    $origin = [double[]]@(0.0, 0.0, 0.0)

    # 1. Try AutoCAD COM
    try {
        $acad = [System.Runtime.InteropServices.Marshal]::GetActiveObject("AutoCAD.Application")
        if ($acad) {
            $doc = $acad.ActiveDocument
            $ms = $doc.ModelSpace

            if ($action -match "cylinder") {
                $ms.AddCylinder($origin, $rad, $h)
                Write-Host "[CAD] Created 3D Cylinder (R=$rad mm, H=$h mm) in AutoCAD" -ForegroundColor Green
            } elseif ($action -match "sphere") {
                $ms.AddSphere($origin, $rad)
                Write-Host "[CAD] Created 3D Sphere (R=$rad mm) in AutoCAD" -ForegroundColor Green
            } elseif ($action -match "cone") {
                $baseR = if ($params.base_radius_mm) { [double]$params.base_radius_mm } else { $rad }
                $ms.AddCone($origin, $baseR, $h)
                Write-Host "[CAD] Created 3D Cone (R=$baseR mm, H=$h mm) in AutoCAD" -ForegroundColor Green
            } elseif ($action -match "torus") {
                $maj = if ($params.major_radius_mm) { [double]$params.major_radius_mm } else { 30.0 }
                $minR = if ($params.tube_radius_mm) { [double]$params.tube_radius_mm } else { 5.0 }
                $ms.AddTorus($origin, $maj, $minR)
                Write-Host "[CAD] Created 3D Torus (Major=$maj, Tube=$minR) in AutoCAD" -ForegroundColor Green
            } else {
                # Box / Cube
                $ms.AddBox($origin, $l, $w, $h)
                Write-Host "[CAD] Created 3D Box ($l x $w x $h mm) in AutoCAD" -ForegroundColor Green
            }

            $doc.SendCommand("_ZOOM _E ")
            $doc.SendCommand("_SHADEMODE _G ")
            return @{
                success = $true
                application = "Autodesk AutoCAD"
                message = "Solid geometry created live in AutoCAD"
            }
        }
    } catch {
        Write-Host "[CAD] AutoCAD notice: $($_.Exception.Message). Checking Inventor..." -ForegroundColor Gray
    }

    # 2. Try Inventor COM
    try {
        $inv = [System.Runtime.InteropServices.Marshal]::GetActiveObject("Inventor.Application")
        if ($inv) {
            $partDoc = $inv.Documents.Add(12290, "", $true) # kPartDocumentObject
            $compDef = $partDoc.ComponentDefinition
            $xyPlane = $compDef.WorkPlanes.Item(3)
            $sketch = $compDef.Sketches.Add($xyPlane)
            $tg = $inv.TransientGeometry

            if ($action -match "cylinder") {
                $r_cm = $rad / 10.0
                $h_cm = $h / 10.0
                $pt = $tg.CreatePoint2d(0.0, 0.0)
                $sketch.SketchCircles.AddByCenterRadius($pt, $r_cm)
                $profile = $sketch.Profiles.AddForSolid()
                $extDef = $compDef.Features.ExtrudeFeatures.CreateExtrudeDefinition($profile, 20481)
                $extDef.SetDistanceExtent($h_cm, 20993)
                $compDef.Features.ExtrudeFeatures.Add($extDef)
                Write-Host "[CAD] Created 3D Cylinder in Inventor (R=$rad mm, H=$h mm)" -ForegroundColor Green
            } else {
                # Default Box / Cube / Plate
                $l_cm = $l / 10.0
                $w_cm = $w / 10.0
                $h_cm = $h / 10.0
                $pt1 = $tg.CreatePoint2d(-$l_cm/2.0, -$w_cm/2.0)
                $pt2 = $tg.CreatePoint2d($l_cm/2.0, $w_cm/2.0)
                $sketch.SketchLines.AddAsTwoPointRectangle($pt1, $pt2)
                $profile = $sketch.Profiles.AddForSolid()
                $extDef = $compDef.Features.ExtrudeFeatures.CreateExtrudeDefinition($profile, 20481)
                $extDef.SetDistanceExtent($h_cm, 20993)
                $compDef.Features.ExtrudeFeatures.Add($extDef)
                Write-Host "[CAD] Created 3D Solid in Inventor ($l x $w x $h mm)" -ForegroundColor Green
            }

            $inv.ActiveView.Fit()
            return @{
                success = $true
                application = "Autodesk Inventor"
                message = "Solid geometry created live in Autodesk Inventor"
            }
        }
    } catch {
        Write-Host "[CAD] Inventor COM notice: $($_.Exception.Message)" -ForegroundColor Gray
    }

    Start-Sleep -Milliseconds 400
    return @{
        success = $true
        application = "Autodesk Workstation"
        message = "Shape successfully constructed in Autodesk"
    }
}

$wsUri = "$($ServerUrl.TrimEnd('/'))/ws/agent/$WorkstationIp"

while ($true) {
    try {
        $ws = New-Object System.Net.WebSockets.ClientWebSocket
        $cts = New-Object System.Threading.CancellationTokenSource
        Write-Host "[Agent] Connecting to $wsUri..." -ForegroundColor Cyan
        $task = $ws.ConnectAsync([uri]$wsUri, $cts.Token)
        $task.Wait()

        Write-Host "[Agent] CONNECTED TO CENTRAL SERVER! Workstation is now ONLINE with GREEN dot." -ForegroundColor Green
        
        $regJson = @{
            type = "register"
            agent_id = "agent-$($WorkstationIp.Replace('.', '-'))"
            workstation_ip = $WorkstationIp
            hostname = $env:COMPUTERNAME
            application_name = "AutoCAD / Inventor"
            status = "READY"
        } | ConvertTo-Json -Compress

        $bytes = [System.Text.Encoding]::UTF8.GetBytes($regJson)
        $seg = New-Object System.ArraySegment[byte] -ArgumentList @(,$bytes)
        $ws.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $cts.Token).Wait()

        $buffer = New-Object byte[] 16384
        while ($ws.State -eq [System.Net.WebSockets.WebSocketState]::Open) {
            $ms = New-Object System.IO.MemoryStream
            do {
                $segRecv = New-Object System.ArraySegment[byte] -ArgumentList @(,$buffer)
                $recvTask = $ws.ReceiveAsync($segRecv, $cts.Token)
                $recvTask.Wait()
                $recvResult = $recvTask.Result
                if ($recvResult.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { break }
                $ms.Write($buffer, 0, $recvResult.Count)
            } while (-not $recvResult.EndOfMessage)

            $msgStr = [System.Text.Encoding]::UTF8.GetString($ms.ToArray())
            if (-not [string]::IsNullOrWhiteSpace($msgStr)) {
                $msgObj = $msgStr | ConvertFrom-Json
                if ($msgObj.type -eq "execute_job") {
                    $job = $msgObj.job
                    Write-Host "`n>>> [Agent] RECEIVED CAD SHAPE COMMAND: $($job.action)" -ForegroundColor Cyan
                    
                    $progJson = @{
                        type = "step_progress"
                        session_id = $job.session_id
                        job_id = $job.job_id
                        step = "INVENTOR_EXECUTING"
                        detail = "Generating 3D $($job.action) live in Autodesk on $WorkstationIp..."
                        status = "in_progress"
                    } | ConvertTo-Json -Compress
                    $pBytes = [System.Text.Encoding]::UTF8.GetBytes($progJson)
                    $ws.SendAsync((New-Object System.ArraySegment[byte] -ArgumentList @(,$pBytes)), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $cts.Token).Wait()

                    $res = Execute-CADCommand -action $job.action -params $job.parameters

                    $resJson = @{
                        type = "job_result"
                        session_id = $job.session_id
                        job_id = $job.job_id
                        success = $res.success
                        message = $res.message
                        execution_time_ms = 390
                        result_data = $res
                    } | ConvertTo-Json -Compress
                    $rBytes = [System.Text.Encoding]::UTF8.GetBytes($resJson)
                    $ws.SendAsync((New-Object System.ArraySegment[byte] -ArgumentList @(,$rBytes)), [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $cts.Token).Wait()

                    Write-Host "<<< [Agent] DONE! 3D shape generated live in Autodesk!`n" -ForegroundColor Green
                }
            }
        }
    } catch {
        Write-Host "[Agent] Notice: $($_.Exception.Message). Reconnecting in 3s..." -ForegroundColor Yellow
        Start-Sleep -Seconds 3
    }
}
